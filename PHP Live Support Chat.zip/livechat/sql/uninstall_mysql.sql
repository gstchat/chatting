DROP TABLE %db_name%.mirrormx_customer_chat_user;

DROP TABLE %db_name%.mirrormx_customer_chat_message;

DROP TABLE %db_name%.mirrormx_customer_chat_data;
